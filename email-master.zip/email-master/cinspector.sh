#!/bin/sh
# script to monitor for attacks

while true; do iptables -nvL INPUT > /tmp/now; clear; colortail /tmp/now; sleep 10; clear; /usr/local/ddos/ddos.sh -v; sleep 5; clear; colortail /var/log/messages; sleep 10; clear; /bin/procmon.sh; sleep 5; done
